import React from "react"

export default function NewBooks() {
    return <h1>New Books</h1>
}