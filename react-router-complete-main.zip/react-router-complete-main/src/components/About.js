import React from "react"

export default function About() {
    return <h1>About Us</h1>
}