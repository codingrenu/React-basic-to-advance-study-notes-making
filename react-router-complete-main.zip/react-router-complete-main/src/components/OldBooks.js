import React from "react"

export default function OldBooks() {
    return <h1>Old Books</h1>
}